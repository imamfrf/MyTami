package com.infomedia.mytami

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import com.aurelhubert.ahbottomnavigation.AHBottomNavigation
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem
import android.support.v4.content.ContextCompat
import android.support.annotation.ColorRes
import android.support.v4.app.Fragment
import kotlinx.android.synthetic.main.activity_main.*




class MainActivity : AppCompatActivity() {
    private var btmNav: BottomNavigationView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //custom toolbar
//        setSupportActionBar(findViewById(R.id.toolbar_main))


        //bottom navigation bar
        val item1 = AHBottomNavigationItem("Home", R.drawable.ic_home_24px)
        val item2 = AHBottomNavigationItem("Progress", R.drawable.ic_hourglass)
        val item3 = AHBottomNavigationItem("Profile", R.drawable.ic_id_person_20px)

        bottom_navigation.addItem(item1)
        bottom_navigation.addItem(item2)
        bottom_navigation.addItem(item3)

        bottom_navigation.setCurrentItem(0)

        // Set listeners
        bottom_navigation.setOnTabSelectedListener(AHBottomNavigation.OnTabSelectedListener { position, wasSelected ->
            // Do something cool here...
            true
        })

    }

    private fun fetchColor(@ColorRes color: Int): Int {
        return ContextCompat.getColor(this, color)
    }

    fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction().replace(R.id.fragment_container, fragment).commit()
        return true
    }
}
